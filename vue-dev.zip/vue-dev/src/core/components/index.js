import KeepAlive from './keep-alive'

export default {
  KeepAlive
}
